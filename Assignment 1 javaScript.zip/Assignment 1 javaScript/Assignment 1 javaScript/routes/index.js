﻿'use strict';
var express = require('express');
var router = express.Router();

router.get('/', function (req, res) {
    res.render('index', { title: 'Express' });
});

/* getting home page*/
router.get('/Home', function (req, res) {
    res.render('Home', { Home: 'Home Page' });
});

/* getting service page*/
router.get('/Service', function (req, res) {
    res.render('Service', { Service: 'Service Page' });
});

/* getting project page*/
router.get('/Project', function (req, res) {
    res.render('Project', { Project: 'Project Page' });
});

/* getting contact me page*/
router.get('/ContactMe', function (req, res) {
    res.render('ContactMe', { ContactMe: 'Contact Page' });
});

/* getting aboutme page*/
router.get('/AboutMe', function (req, res) {
    res.render('AboutMe', { AboutMe: 'AboutMe Page' });
});


module.exports = router;